package com.sunbeam;

import java.util.ArrayList;
import java.util.List;

public class Demo01Main {
	public static void main1(String[] args) {
		try(StudentDao studDao = new StudentDaoImpl()){
			Student s = studDao.findByID(1); 
			System.out.println(s.toString());
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		List<Student> list = new ArrayList<>(); 
		try(StudentDao studentDao = new StudentDaoImpl()){
			list = studentDao.findAll(); 
			for (Student s : list) {
				System.out.println(s.toString());
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void main3(String[] args) {
		try(StudentDao studDao = new StudentDaoImpl()){
			Student s = new Student(11, "Nitin", 91.33); 
			int cnt = studDao.save(s); 
			System.out.println("Rows affected : " +cnt);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
